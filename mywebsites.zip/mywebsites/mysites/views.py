from django.shortcuts import render,render_to_response
from django.http import HttpResponse
#from django.views
# Create your views here.

def index(request):
    return render_to_response('index.html')


def About(request):
    return render_to_response('About.html')